#ColorsLib Written in ruby. Made 8/29/2026
#Official Python-S library

$lines = [] #The individual lines
$pos = 0 #Position in the line
$read = true #Tells the parser if it should read the code. off for comments and strings
$depth = 0 #Depth in the parenthesis. Currently not needed.
$strin = false #If the parser is in a string

VERS = "1.01.00"


def parse
    lines = File.read("output.pys")

    File.write("output.pys", "") #Clears file
    
    lines.each_line do |line| #For line in lines
        $lchar = line.chars
        $pos = 0
        $read = true
        $strin = false
        
        while $pos < $lchar.length
            if $lchar[$pos] == '"'
                $read = ! $read #Flips reading state
                $strin = ! $strin #Flips string 
            end

            if $read
                if $lchar[$pos] == "#"
                    $read = false
                end
            end

            if $read
                if $lchar[$pos...($pos+2)] == "$$"
                    $read = false 
                end
            end

            #Red Text
            if $strin
                if $lchar[$pos...$pos+3].join == "RD<"
                    $lchar.slice!($pos...($pos + 3))
                    $lchar.insert($pos, "\033[31m")
                    $pos += 1
                    next
                end
            end

            #Blue Text
            if $strin
                if $lchar[$pos...$pos+3].join == "BU<"
                    $lchar.slice!($pos...($pos + 3))
                    $lchar.insert($pos, "\033[34m")
                    $pos += 1
                    next
                end
            end

            #Green Text
            if $strin
                if $lchar[$pos...$pos+3].join == "GR<"
                    $lchar.slice!($pos...($pos + 3))
                    $lchar.insert($pos, "\033[32m")

                    $pos += 1
                    next
                end
            end

            #Reset Text
            if $strin
                if $lchar[$pos...$pos+3].join == ">RS"
                    $lchar.slice!($pos...($pos + 3))
                    $lchar.insert($pos, "\033[0m")
                    $pos += 1
                    next
                end
            end

            #Yellow Text
            if $strin
                if $lchar[$pos...$pos+3].join == "YL<"
                    $lchar.slice!($pos...($pos + 3))
                    $lchar.insert($pos, "\033[33m")
                    $pos += 1
                    next
                end
            end

            #Magenta Text
            if $strin
                if $lchar[$pos...$pos+3].join == "MG<"
                    $lchar.slice!($pos...($pos + 3))
                    $lchar.insert($pos, "\033[35m")
                    $pos += 1
                    next
                end
            end

            #Cyan Text
            if $strin
                if $lchar[$pos...$pos+3].join == "CY<"
                    $lchar.slice!($pos...($pos + 3))
                    $lchar.insert($pos, "\033[36m")
                    $pos += 1
                    next
                end
            end

            #Black Text
            if $strin
                if $lchar[$pos...$pos+3].join == "BL<"
                    $lchar.slice!($pos...($pos + 3))
                    $lchar.insert($pos, "\033[30m")
                    $pos += 1
                    next
                end
            end

            #White Text
            if $strin 
                if $lchar[$pos...$pos+3].join == "WH<"
                    $lchar.slice!($pos...($pos + 3))
                    $lchar.insert($pos, "\033[37m")
                    $pos += 1
                    next
                end
            end



            $pos += 1


        end
    File.open("output.pys", "a" ) do |file|
        file.write($lchar.join)
    end

    end

end

parse
