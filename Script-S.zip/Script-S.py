#Script-S Library 1.00.00 Made 8/28/2026
#Official Python-S library
import shutil
import sys
import subprocess
from pathlib import Path
import os
import time

LINES = [] #The individual lines
POS = 0 #Position in the line
READ = True #Tells the parser if it should read the code. off for comments and strings
DEPTH = 0 #Depth in the parenthesis. Currently not needed.
STRIN = False #If the parser is in a string
LINUM = 1 #Number of the line the parser is on
CB = [] #Comment and statement end syntax

VERS = "1.00.00"


def PARSE():
    global READ
    global DEPTH
    global POS
    global LCHAR
    global STRIN
    global LINUM
    global CMTZ
    global CB

    if Path("LIBBCOMMENTS.txt").exists():
        with open ("LIBCOMMENTS.txt", "r") as fiel:
            CMZ = file.read().splitlines()
            for i in CMZ:
                CB.append(i)

    with open("output.pys", "r") as file:
        lines = file.readlines()

    open("output.pys", "w").close() #clears the file
    LINUM = 0

    CB = [";", "#", "$$", "//"]

    file_path = Path("PS_STATEMENT.txt")
    if file_path.exists():
        with open ("PS_STATEMENT.txt","r") as file:
            STATEMENTS = file.read().splitlines()
            for i in STATEMENTS:
                CB.append(i)

    for line in lines:
        LINUM += 1
        LCHAR = list(line)
        POS = 0
        READ = True
        STRIN = False

        while POS < len(LCHAR):

            if LCHAR[POS] == '"':
                READ = not READ #Flips reading state
                STRIN = not STRIN #Flips string 

            if READ == True:
                if LCHAR[POS] == "#":
                    READ = False

            if READ == True:
                if LCHAR[POS:POS+2] == "$$":
                    READ = False 

            if READ == True:
                if LCHAR[0:2] == "//":
                    READ = False 

            if READ == True:
                if not any(x in "".join(LCHAR) for x in CB):
                    READ = False 
                    print(f"Error on line {LINUM}. No semicolon found ")


            # Logical And operator
            if STRIN != True and READ == True:
                if "".join(LCHAR[POS:POS+2]) == "&&":
                    del LCHAR[POS:POS+2]
                    LCHAR.insert(POS, "and")
                    POS += 1
                    continue

            # Logical Or operator
            if STRIN != True and READ == True:
                if "".join(LCHAR[POS:POS+2]) == "||":
                    del LCHAR[POS:POS+2]
                    LCHAR.insert(POS, "or")
                    POS += 1
                    continue

            # unless --> if not
            if STRIN != True and READ == True:
                if "".join(LCHAR[POS:POS+6]) == "unless":
                    del LCHAR[POS:POS+6]
                    LCHAR.insert(POS, "if not")
                    POS += 1
                    continue

            # // comments at start of line
            if STRIN != True:
                if "".join(LCHAR[0:2]) == "//":
                    del LCHAR[0:2]
                    LCHAR.insert(POS, "#")
                    READ = False
                    POS += 1
                    continue

            # // comments after a semicolon
            if STRIN != True:
                if "".join(LCHAR[POS:POS+4]).replace(" ", "") == ";//":
                    del LCHAR[POS:POS+3]
                    LCHAR.insert(POS, "#")
                    READ = False
                    POS += 1
                    continue

            # Clears semicolons
            if STRIN != True and READ == True:
                if "".join(LCHAR[POS]) == ";":
                    del LCHAR[POS]
                    POS += 1
                    continue






            POS += 1
        with open("output.pys", "a") as file:
            file.write("".join(LCHAR))

PARSE()





