#Colors Library. Made 8/27/2026
#Official Python-S library
import shutil
import sys
import subprocess
from pathlib import Path
import os
import time

LINES = [] #The individual lines
POS = 0 #Position in the line
READ = True #Tells the parser if it should read the code. off for comments and strings
DEPTH = 0 #Depth in the parenthesis. Currently not needed.
STRIN = False #If the parser is in a string


VERS = "1.00.00"


def PARSE():
    global READ
    global DEPTH
    global POS
    global LCHAR
    global STRIN

    with open("output.pys", "r") as file:
        lines = file.readlines()

    open("output.pys", "w").close() #clears the file

    for line in lines:
        LCHAR = list(line)
        POS = 0
        READ = True
        STRIN = False

        while POS < len(LCHAR):

            if LCHAR[POS] == '"':
                READ = not READ #Flips reading state
                STRIN = not STRIN #Flips string 

            if READ == True:
                if LCHAR[POS] == "#":
                    READ = False

            if READ == True:
                if LCHAR[POS:POS+2] == "$$":
                    READ = False 

            #Red Text
            if STRIN == True:
                if "".join(LCHAR[POS:POS+3]) == "RD<":
                    del LCHAR[POS:POS+3]
                    LCHAR.insert(POS, "\033[31m")
                    POS += 1
                    continue

            #Blue Text
            if STRIN == True:
                if "".join(LCHAR[POS:POS+3]) == "BU<":
                    del LCHAR[POS:POS+3]
                    LCHAR.insert(POS, "\033[34m")
                    POS += 1
                    continue

            #Green Text
            if STRIN == True:
                if "".join(LCHAR[POS:POS+3]) == "GR<":
                    del LCHAR[POS:POS+3]
                    LCHAR.insert(POS, "\033[32m")

                    POS += 1
                    continue

            #Reset Text
            if STRIN == True:
                if "".join(LCHAR[POS:POS+3]) == ">RS":
                    del LCHAR[POS:POS+3]
                    LCHAR.insert(POS, "\033[0m")
                    POS += 1
                    continue


            POS += 1
        with open("output.pys", "a") as file:
            file.write("".join(LCHAR))

PARSE()





