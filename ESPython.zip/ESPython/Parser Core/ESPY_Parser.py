#Parser. Made 8/25/2026
import shutil
import sys
import subprocess
from pathlib import Path
import os
import time

LINES = [] #The individual lines
POS = 0 #Position in the line
READ = True #Tells the parser if it should read the code. off for comments and strings
DEPTH = 0 #Depth in the parenthesis
LCHAR = [] #line split into it's chars
STRIN = False #If the parser is in a string


VERS = "1.02.04"

#Finds Libraries
def LIBFINDER():
    libraries = [] #list of libraries
    new_lines = [] #the new lines
    with open("output.esp", "r") as file:
        lines = file.readlines()

    new_lines = []

    for line in lines:
        LCHAR = list(line)
        remove_line = False
        lang = ""
        FILE = ""
        LIBLINE = []

        if line.lstrip().startswith("lib "):
            LIBLINE = line.split()
            
            #Checks that the Statement defining txt is there before acting upon it
            file_path = Path("ESPY_STATEMENT.txt")
            if file_path.exists():
                with open ("ESPY_STATEMENT.txt","r") as file:
                    STATEMENTS = file.read().splitlines()
                    for i in STATEMENTS:
                        LIBLINE = [x.replace(i, "") for x in LIBLINE] #Replaces custom lib syntax for the parser


            if len(LIBLINE) >2:
                LIBLINE = [x.replace(";", "") for x in LIBLINE] #Replaces semicolons used in Python-S
                FILE = LIBLINE[1]
                lang = LIBLINE[2]
                remove_line = True
                libraries.append((lang, FILE))
                    
            else:
                print(f"Error, missing argument(s) for library {FILE} ")


        if not remove_line:
            new_lines.append(line)

    #Saves the Parser's changes
    with open("output.esp", "w") as file:
        file.writelines(new_lines)

    #Runs the list of libraries
    for lang, FILE in libraries:
        subprocess.run([lang, FILE])





def PARSE():
    global READ
    global DEPTH
    global POS
    global LCHAR
    global STRIN

    with open("code.esp", "r") as file:
        lines = file.readlines()

    for line in lines:
        LCHAR = list(line)
        POS = 0
        READ = True
        STRIN = False

        while POS < len(LCHAR):

            if LCHAR[POS] == '"':
                READ = not READ #Flips reading state
                STRIN = not STRIN #Flips string moe

            if READ == True:
                if LCHAR[POS] == "#":
                    READ = False



            #Incremental
            if READ == True and STRIN == False:
                if "".join(LCHAR[POS:POS+2]) == "++":
                    del LCHAR[POS:POS+2]
                    LCHAR.insert(POS, " += 1")

                    POS += len(" += 1")
                    continue
            
            #Decremental
            if READ == True and STRIN == False:
                if "".join(LCHAR[POS:POS+2]) == "--":
                    del LCHAR[POS:POS+2]
                    LCHAR.insert(POS, " -= 1")
                    POS += len(" -= 1")
                    continue
            
            # $$ Comments
            if READ == True and STRIN == False:
                if "".join(LCHAR[POS:POS+2]) == "$$":
                    del LCHAR[POS:POS+2]
                    LCHAR.insert(POS, "#")
                    POS +=2
                    READ = False #Turns off for the comment :D
                    continue

            POS += 1

        with open("output.esp", "a") as file:
            file.write("".join(LCHAR))

PARSE()

# Runs LIBFINDER
LIBFINDER()

# copies output to PS_EXECUTE
shutil.copyfile("output.esp", "ESPY_EXECUTE.py")

# Clears output.pys
with open("output.esp", "w") as file:
    pass

print("\033[34mFile Transpiled Successfully\033[0m")

#Auto execution
Setts = Path(__file__).parent.parent / "Intermediary Data" / "ESPY_Settings.txt"
with open(Setts, "r") as file:
    SETT = file.readline()
    if SETT[1] == "1": #Checks the setting for auto execution
        subprocess.run("python","ESPY_EXECUTE.py")