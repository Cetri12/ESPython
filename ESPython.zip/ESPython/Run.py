#Python-S. 1.00.00 Made 8/25/2026
#Adds additional libraries to python.
import subprocess
from pathlib import Path
import os
import platform
import time
import sys


Version = "\033[34mVersion: 1.04.03\033[0m"

#Clears executable file and output.pys
with open("ESPY_EXECUTE.py", "w") as f:
    pass
with open("output.epy", "w") as f:
    pass

settingpath = Path(__file__).parent / "Intermediary Data" / "ESPY_Settings.txt"
with open(settingpath, "r") as file:
    SETT = file.readline()

    if SETT[0] == "1": #Checks the setting for terminal feedback
        print("===Python-S===")
        print(Version)
        print("Please insert code.pys into folder. Dont worry if it's code.pys.txt. I got you")
        OSTYPE = platform.system()
        print("OS:",OSTYPE)

#Renames .esp.txt to .esp
if Path("code.esp.txt").exists():
    os.rename("code.esp.txt", "code.esp")

if Path("output.esp.txt").exists():
    os.rename("output.esp.txt", "output.esp")

#Checks that the parser exists
file_path = Path(__file__).parent / "Parser Core" / "ESPY_Parser.py"
if not file_path.exists():
    print("Error: Parser not found")
else:
    print("Parser Docked Sucessfully")

script = Path(__file__).parent / "Parser Core" / "ESPY_Parser.py"
subprocess.run([sys.executable, script])