#Colors Library 1.01.00 Made 8/28/2026
#Official ESPython library
import shutil
import sys
import subprocess
from pathlib import Path
import os
import time

LINES = [] #The individual lines
POS = 0 #Position in the line
READ = True #Tells the parser if it should read the code. off for comments and strings
DEPTH = 0 #Depth in the parenthesis. Currently not needed.
STRIN = False #If the parser is in a string


VERS = "1.01.00"


def PARSE():
    global READ
    global DEPTH
    global POS
    global LCHAR
    global STRIN

    with open("output.esp", "r") as file:
        lines = file.readlines()

    open("output.esp", "w").close() #clears the file

    for line in lines:
        LCHAR = list(line)
        POS = 0
        READ = True
        STRIN = False

        while POS < len(LCHAR):

            if LCHAR[POS] == '"':
                READ = not READ #Flips reading state
                STRIN = not STRIN #Flips string 

            if READ == True:
                if LCHAR[POS] == "#":
                    READ = False

            if READ == True:
                if LCHAR[POS:POS+2] == "$$":
                    READ = False 

            #Red Text
            if STRIN == True:
                if "".join(LCHAR[POS:POS+3]) == "RD<":
                    del LCHAR[POS:POS+3]
                    LCHAR.insert(POS, "\033[31m")
                    POS += 1
                    continue

            #Blue Text
            if STRIN == True:
                if "".join(LCHAR[POS:POS+3]) == "BU<":
                    del LCHAR[POS:POS+3]
                    LCHAR.insert(POS, "\033[34m")
                    POS += 1
                    continue

            #Green Text
            if STRIN == True:
                if "".join(LCHAR[POS:POS+3]) == "GR<":
                    del LCHAR[POS:POS+3]
                    LCHAR.insert(POS, "\033[32m")

                    POS += 1
                    continue

            #Reset Text
            if STRIN == True:
                if "".join(LCHAR[POS:POS+3]) == ">RS":
                    del LCHAR[POS:POS+3]
                    LCHAR.insert(POS, "\033[0m")
                    POS += 1
                    continue

            #Yellow Text
            if STRIN == True:
                if "".join(LCHAR[POS:POS+3]) == "YL<":
                    del LCHAR[POS:POS+3]
                    LCHAR.insert(POS, "\033[33m")
                    POS += 1
                    continue

            #Magenta Text
            if STRIN == True:
                if "".join(LCHAR[POS:POS+3]) == "MG<":
                    del LCHAR[POS:POS+3]
                    LCHAR.insert(POS, "\033[35m")
                    POS += 1
                    continue

            #Cyan Text
            if STRIN == True:
                if "".join(LCHAR[POS:POS+3]) == "CY<":
                    del LCHAR[POS:POS+3]
                    LCHAR.insert(POS, "\033[36m")
                    POS += 1
                    continue

            #Black Text
            if STRIN == True:
                if "".join(LCHAR[POS:POS+3]) == "BL<":
                    del LCHAR[POS:POS+3]
                    LCHAR.insert(POS, "\033[30m")
                    POS += 1
                    continue

            #White Text
            if STRIN == True:
                if "".join(LCHAR[POS:POS+3]) == "WH<":
                    del LCHAR[POS:POS+3]
                    LCHAR.insert(POS, "\033[37m")
                    POS += 1
                    continue



            POS += 1
        with open("output.esp", "a") as file:
            file.write("".join(LCHAR))

PARSE()





